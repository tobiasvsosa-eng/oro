// ORITO — bot de WhatsApp para GLD.
// Sin audios ni IA: solo botones y numeros.

const VERSION = "gld-simple-v1";
const GRAPH = "https://graph.facebook.com/v25.0";

// ---------------------------------------------------------------- salida
async function apiWA(env, payload) {
  if (!env.WA_PHONE_ID || !env.WA_TOKEN) {
    console.log("WA: falta WA_PHONE_ID o WA_TOKEN");
    return false;
  }
  // los celulares argentinos van con o sin el 9: probamos las dos
  const destinos = [payload.to];
  if (/^549\d+$/.test(payload.to)) destinos.push("54" + payload.to.slice(3));
  else if (/^54\d+$/.test(payload.to)) destinos.push("549" + payload.to.slice(2));

  for (const to of destinos) {
    const r = await fetch(`${GRAPH}/${env.WA_PHONE_ID}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${env.WA_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({ ...payload, to, messaging_product: "whatsapp" }),
    });
    if (r.ok) return true;
    console.log("WA fallo enviando a", to, r.status, (await r.text()).slice(0, 200));
  }
  return false;
}

export async function enviar(env, a, texto) {
  return apiWA(env, { to: a, type: "text", text: { body: String(texto).slice(0, 3500) } });
}

async function enviarBotones(env, a, texto, botones) {
  const ok = await apiWA(env, {
    to: a,
    type: "interactive",
    interactive: {
      type: "button",
      body: { text: String(texto).slice(0, 1000) },
      action: {
        buttons: botones.slice(0, 3).map((b) => ({
          type: "reply", reply: { id: b.id.slice(0, 250), title: b.titulo.slice(0, 20) },
        })),
      },
    },
  });
  if (!ok) await enviar(env, a, texto + "\n\n" + botones.map((b, i) => `${i + 1}) ${b.titulo}`).join("\n"));
  return ok;
}

const menu = (texto) => ({
  texto: texto || "Que hiciste?",
  botones: [
    { id: "compre", titulo: "Compre" },
    { id: "vendi", titulo: "Vendi" },
    { id: "estado", titulo: "Como voy" },
  ],
});

// ---------------------------------------------------------------- diagnostico
export function waEstado(env) {
  const set = (v) => (v ? "OK" : "FALTA");
  return new Response(JSON.stringify({
    version: VERSION,
    WA_TOKEN: set(env.WA_TOKEN),
    WA_PHONE_ID: env.WA_PHONE_ID ? "OK (" + env.WA_PHONE_ID + ")" : "FALTA",
    WA_VERIFY_TOKEN: set(env.WA_VERIFY_TOKEN),
    WA_ALLOW: env.WA_ALLOW ? "OK (" + env.WA_ALLOW + ")" : "FALTA",
    WA_USER_SUB: set(env.WA_USER_SUB),
    DB_binding: env.DB ? "OK" : "FALTA",
  }, null, 2), { headers: { "Content-Type": "application/json" } });
}

// Sin esto Meta valida el webhook pero nunca manda los mensajes reales.
export async function waSuscribir(env) {
  if (!env.WA_WABA_ID || !env.WA_TOKEN) {
    return new Response(JSON.stringify({ error: "faltan WA_WABA_ID o WA_TOKEN" }), { status: 400 });
  }
  const r = await fetch(`${GRAPH}/${env.WA_WABA_ID}/subscribed_apps`, {
    method: "POST", headers: { Authorization: `Bearer ${env.WA_TOKEN}` },
  });
  return new Response(JSON.stringify({ status: r.status, respuesta: await r.text() }, null, 2),
    { headers: { "Content-Type": "application/json" } });
}

// ---------------------------------------------------------------- webhook
export async function waWebhook(request, env, url, h, ctx) {
  if (request.method === "GET") {
    const mode = url.searchParams.get("hub.mode");
    const token = url.searchParams.get("hub.verify_token");
    if (mode === "subscribe" && token && token === env.WA_VERIFY_TOKEN) {
      return new Response(url.searchParams.get("hub.challenge"), { status: 200 });
    }
    return new Response("forbidden", { status: 403 });
  }
  if (request.method !== "POST") return new Response("ok");

  const body = await request.json().catch(() => null);
  const msg = body?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
  if (!msg) return new Response("ok");

  const desde = msg.from;
  const permitidos = String(env.WA_ALLOW || "").split(",").map((s) => s.trim()).filter(Boolean);
  if (permitidos.length && !permitidos.includes(desde)) {
    await enviar(env, desde, "Este bot es privado.");
    return new Response("ok");
  }
  const sub = env.WA_USER_SUB;
  if (!sub) {
    await enviar(env, desde, "Falta configurar WA_USER_SUB en el Worker.");
    return new Response("ok");
  }

  // contestamos rapido y procesamos aparte: si no, Meta reintenta y duplica
  const tarea = manejar(env, sub, msg, desde, h);
  if (ctx && ctx.waitUntil) ctx.waitUntil(tarea); else await tarea;
  return new Response("ok");
}

async function manejar(env, sub, msg, desde, h) {
  try {
    let texto = "", opcion = null;
    if (msg.type === "text") texto = msg.text?.body || "";
    else if (msg.type === "interactive") {
      opcion = msg.interactive?.button_reply?.id || null;
      texto = msg.interactive?.button_reply?.title || "";
    } else if (msg.type === "button") {
      opcion = msg.button?.payload || null;
      texto = msg.button?.text || "";
    } else {
      await responder(env, desde, menu("Mandame texto o toca un boton."));
      return;
    }

    const r = await procesar(env, sub, texto, opcion, h);
    await responder(env, desde, r);
  } catch (e) {
    console.log("WA error:", String(e).slice(0, 300));
    await enviar(env, desde, "Se me complico: " + String(e).slice(0, 120));
  }
}

async function responder(env, a, r) {
  if (typeof r === "string") return enviar(env, a, r);
  if (r && r.botones) return enviarBotones(env, a, r.texto, r.botones);
  return enviar(env, a, String(r));
}

// ---------------------------------------------------------------- logica
// Estados posibles guardados en wa_pendientes:
//   {paso:"monto", tipo:"compra"|"venta"}          esperando el monto en pesos
//   {paso:"confirmar", datos:{...}}                esperando si/no
//   {paso:"cantidad", datos:{...}}                 esperando la cantidad corregida
async function procesar(env, sub, texto, opcion, h) {
  const t = (texto || "").toLowerCase().trim();
  const pend = await h.pendienteDe(env, sub);
  let estado = null;
  try { estado = pend ? JSON.parse(pend.payload) : null; } catch {}

  // ---------- botones ----------
  if (opcion === "compre" || opcion === "vendi") {
    const tipo = opcion === "compre" ? "compra" : "venta";
    if (tipo === "venta") {
      const ten = await h.tenencia(env, sub);
      if (!(ten.cant > 0)) return menu("No tenes cedears para vender.");
    }
    await h.guardarPendiente(env, sub, JSON.stringify({ paso: "monto", tipo }));
    return tipo === "compra"
      ? "Cuantos pesos pusiste? Escribime el numero.\nEj: 230000"
      : "Cuantos pesos cobraste? Escribime el numero.\nEj: 150000";
  }

  if (opcion === "estado") {
    await h.limpiarPendiente(env, sub);
    const txt = await h.resumen(env, sub);
    return { texto: txt, botones: [{ id: "compre", titulo: "Compre" }, { id: "vendi", titulo: "Vendi" }] };
  }

  if (opcion === "si" && estado?.paso === "confirmar") {
    await h.limpiarPendiente(env, sub);
    const r = await h.guardar(env, sub, estado.datos);
    if (r.error) return menu(r.error);
    const resumen = await h.resumen(env, sub);
    return { texto: `Listo, anotado.\n\n${resumen}`, botones: [{ id: "estado", titulo: "Ver de nuevo" }] };
  }

  if (opcion === "no") {
    await h.limpiarPendiente(env, sub);
    return menu("Listo, no anote nada.");
  }

  if (opcion === "cant" && estado?.paso === "confirmar") {
    await h.guardarPendiente(env, sub, JSON.stringify({ paso: "cantidad", datos: estado.datos }));
    return "Cuantos cedears fueron exactamente? Fijate en tu broker.";
  }

  // ---------- respuestas escritas ----------
  const num = numero(t);

  if (estado?.paso === "monto" && num > 0) {
    const sim = await h.simular(env, sub, num, 0);
    if (sim.error) { await h.limpiarPendiente(env, sub); return menu(sim.error); }

    if (estado.tipo === "venta") {
      const ten = await h.tenencia(env, sub);
      if (sim.cant > ten.cant) sim.cant = ten.cant;
    }

    const datos = { tipo: estado.tipo, montoArs: num, cant: sim.cant, fecha: sim.fecha };
    await h.guardarPendiente(env, sub, JSON.stringify({ paso: "confirmar", datos }));

    const plata = (n) => "$ " + Math.round(n).toLocaleString("es-AR");
    return {
      texto: `${estado.tipo === "compra" ? "Compra" : "Venta"} de ${plata(num)}\n\n` +
        `Serian ${sim.cant} cedears a ${plata(sim.real)} c/u.\n` +
        `GLD hoy US$ ${sim.close.toFixed(2)} · CCL ${plata(sim.fx)}\n\n` +
        `Lo anoto?`,
      botones: [
        { id: "si", titulo: "Si, anotalo" },
        { id: "cant", titulo: "Otra cantidad" },
        { id: "no", titulo: "Cancelar" },
      ],
    };
  }

  if (estado?.paso === "cantidad" && num > 0) {
    const datos = { ...estado.datos, cant: num };
    await h.guardarPendiente(env, sub, JSON.stringify({ paso: "confirmar", datos }));
    const plata = (n) => "$ " + Math.round(n).toLocaleString("es-AR");
    return {
      texto: `${datos.tipo === "compra" ? "Compra" : "Venta"} de ${plata(datos.montoArs)} por ${num} cedears\n` +
        `(${plata(datos.montoArs / num)} cada uno)\n\nLo anoto?`,
      botones: [{ id: "si", titulo: "Si, anotalo" }, { id: "no", titulo: "Cancelar" }],
    };
  }

  // atajos escritos
  if (/^(hola|menu|buenas|ey|hey|\?)/.test(t)) return menu("Hola! Que hiciste?");
  if (/(como voy|estado|cuanto tengo|resumen|posicion)/.test(t)) {
    const txt = await h.resumen(env, sub);
    return { texto: txt, botones: [{ id: "compre", titulo: "Compre" }, { id: "vendi", titulo: "Vendi" }] };
  }
  if (/compre|compra/.test(t)) {
    await h.guardarPendiente(env, sub, JSON.stringify({ paso: "monto", tipo: "compra" }));
    return "Cuantos pesos pusiste? Escribime el numero.";
  }
  if (/vendi|venta/.test(t)) {
    await h.guardarPendiente(env, sub, JSON.stringify({ paso: "monto", tipo: "venta" }));
    return "Cuantos pesos cobraste? Escribime el numero.";
  }

  // un numero suelto sin contexto: asumo compra y pregunto
  if (num > 0) {
    await h.guardarPendiente(env, sub, JSON.stringify({ paso: "monto", tipo: "compra" }));
    return procesar(env, sub, String(num), null, h);
  }

  return menu();
}

// "230000", "230.000", "230 mil", "5 lucas"
function numero(texto) {
  const t = String(texto || "").toLowerCase().replace(/\$/g, " ");
  const m = t.match(/(\d+(?:[.,]\d+)?)/);
  if (!m) return 0;
  let v = parseFloat(m[1].replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
  if (/\b(luca|lucas|mil|k)\b/.test(t) && v < 1000) v *= 1000;
  if (/\b(palo|palos|millon|millones)\b/.test(t) && v < 100000) v *= 1000000;
  return v > 0 ? v : 0;
}
