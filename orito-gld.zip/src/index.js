// ORITO — seguimiento de GLD (cedear, ratio 50:1). Nada mas.
// Web + bot de WhatsApp con botones.

import { waWebhook, waEstado, waSuscribir, enviar as enviarWA } from "./wa.js";

const RATIO = 50;
const COOKIE = "orito_sess";
const SESSION_DAYS = 30;
const UMBRAL = 0.20; // regla del 20%

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      try {
        return await api(request, env, url, ctx);
      } catch (e) {
        return json({ error: "error interno", detail: String(e).slice(0, 200) }, 500);
      }
    }
    return env.ASSETS.fetch(request);
  },

  // corre todos los dias: avisa si GLD toco el 20%
  async scheduled(event, env, ctx) {
    ctx.waitUntil(avisoDiario(env));
  },
};

// ---------------------------------------------------------------- API
async function api(request, env, url, ctx) {
  const { pathname } = url;
  const method = request.method;

  // ---- bot ----
  if (pathname === "/api/wa/webhook") return waWebhook(request, env, url, HELPERS, ctx);
  if (pathname === "/api/wa/estado" && method === "GET") return waEstado(env);
  if (pathname === "/api/wa/suscribir" && method === "GET") return waSuscribir(env);

  // ---- auth ----
  if (pathname === "/api/config" && method === "GET") {
    return json({ clientId: env.GOOGLE_CLIENT_ID });
  }

  if (pathname === "/api/auth/google" && method === "POST") {
    const { credential } = await request.json();
    if (!credential) return json({ error: "falta credential" }, 400);
    const r = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(credential));
    if (!r.ok) return json({ error: "token invalido" }, 401);
    const info = await r.json();
    if (info.aud !== env.GOOGLE_CLIENT_ID) return json({ error: "aud no coincide" }, 401);
    if (Number(info.exp) * 1000 < Date.now()) return json({ error: "token vencido" }, 401);

    await env.DB.prepare(
      `INSERT INTO users (sub, email, name) VALUES (?1,?2,?3)
       ON CONFLICT(sub) DO UPDATE SET email=?2, name=?3`
    ).bind(info.sub, info.email || "", info.name || "").run();

    const exp = Date.now() + SESSION_DAYS * 864e5;
    const payload = b64url(JSON.stringify({ sub: info.sub, email: info.email, name: info.name, exp }));
    const sig = await hmac(env.SESSION_SECRET, payload);
    return json({ ok: true, user: { email: info.email, name: info.name } }, 200, {
      "Set-Cookie": `${COOKIE}=${payload}.${sig}; HttpOnly; Secure; Path=/; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}`,
    });
  }

  if (pathname === "/api/auth/logout" && method === "POST") {
    return json({ ok: true }, 200, { "Set-Cookie": `${COOKIE}=; HttpOnly; Secure; Path=/; SameSite=Lax; Max-Age=0` });
  }

  // ---- precio (publico) ----
  if (pathname === "/api/precio" && method === "GET") return precioGld(env);

  // ---- requiere sesion ----
  const user = await session(request, env);
  if (!user) return json({ error: "sin sesion" }, 401);

  if (pathname === "/api/me" && method === "GET") return json({ email: user.email, name: user.name });

  if (pathname === "/api/operaciones" && method === "GET") {
    const { results } = await env.DB.prepare(
      `SELECT id, fecha, COALESCE(tipo,'compra') AS tipo, precio_gld AS precioGld,
              precio_ars AS precioArs, ccl, cant, entidad
       FROM compras WHERE user_sub=?1 AND COALESCE(activo,'GLD')='GLD'
       ORDER BY fecha ASC, id ASC`
    ).bind(user.sub).all();
    return json(results);
  }

  if (pathname === "/api/operaciones" && method === "POST") {
    const b = await request.json();
    const r = await guardarOperacion(env, user.sub, b);
    return r.error ? json(r, 400) : json(r);
  }

  const opMatch = pathname.match(/^\/api\/operaciones\/(\d+)$/);
  if (opMatch && method === "PATCH") {
    const b = await request.json();
    const id = Number(opMatch[1]);
    const { results } = await env.DB.prepare("SELECT * FROM compras WHERE id=?1 AND user_sub=?2").bind(id, user.sub).all();
    if (!results.length) return json({ error: "no existe" }, 404);
    const a = results[0];
    const fecha = /^\d{4}-\d{2}-\d{2}$/.test(b.fecha || "") ? b.fecha : a.fecha;
    const cant = Number(b.cant) > 0 ? Number(b.cant) : a.cant;
    const tipo = b.tipo === "venta" ? "venta" : "compra";
    const fx = (await cclDe(fecha)) || a.ccl;

    let precioGld = a.precio_gld, precioArs = a.precio_ars;
    if (Number(b.montoArs) > 0 && cant > 0) {
      precioArs = Number(b.montoArs) / cant;
      const close = await closeDe(env, fecha);
      if (close > 0) precioGld = close;
    } else if (Number(b.precioGld) > 0) {
      precioGld = Number(b.precioGld);
      if (fx > 0) precioArs = (precioGld / RATIO) * fx;
    }

    await env.DB.prepare(
      "UPDATE compras SET fecha=?1, cant=?2, tipo=?3, precio_gld=?4, precio_ars=?5, ccl=?6, entidad=?7 WHERE id=?8 AND user_sub=?9"
    ).bind(fecha, cant, tipo, precioGld, precioArs, fx || a.ccl,
      b.entidad !== undefined ? (String(b.entidad).slice(0, 40) || null) : a.entidad, id, user.sub).run();
    return json({ ok: true });
  }

  if (opMatch && method === "DELETE") {
    await env.DB.prepare("DELETE FROM compras WHERE id=?1 AND user_sub=?2").bind(Number(opMatch[1]), user.sub).run();
    return json({ ok: true });
  }

  return json({ error: "no encontrado" }, 404);
}

// ---------------------------------------------------------------- guardar
// Criterio de la planilla: precio por cedear en usd = close de GLD del dia / 50.
// El monto en pesos queda guardado como referencia de lo que realmente pagaste.
async function guardarOperacion(env, sub, b) {
  const fecha = /^\d{4}-\d{2}-\d{2}$/.test(b.fecha || "") ? b.fecha : hoyIso();
  const close = await closeDe(env, fecha);
  if (!(close > 0)) return { error: "no consegui el precio de GLD de esa fecha" };
  const fx = await cclDe(fecha);
  const tipo = b.tipo === "venta" ? "venta" : "compra";

  const pCedUsd = close / RATIO;
  const pCedArs = fx > 0 ? pCedUsd * fx : null;

  let cant = Number(b.cant);
  let precioArs = null;
  const montoArs = Number(b.montoArs);
  const montoUsd = Number(b.montoUsd);

  if (montoArs > 0) {
    if (!(pCedArs > 0)) return { error: "no consegui el dolar de esa fecha" };
    if (!(cant > 0)) cant = Math.max(1, Math.round(montoArs / pCedArs));
    precioArs = montoArs / cant;
  } else if (montoUsd > 0) {
    if (!(cant > 0)) cant = Math.max(1, Math.round(montoUsd / pCedUsd));
    precioArs = pCedArs;
  } else if (cant > 0) {
    precioArs = pCedArs;
  } else {
    return { error: "falta el monto o la cantidad" };
  }

  if (tipo === "venta") {
    const t = await HELPERS.tenencia(env, sub);
    if (cant > t.cant + 1e-9) return { error: `no podes vender ${cant}: tenes ${t.cant} cedears` };
  }

  const res = await env.DB.prepare(
    `INSERT INTO compras (user_sub, fecha, precio_gld, precio_ars, ccl, cant, entidad, tipo, activo)
     VALUES (?1,?2,?3,?4,?5,?6,?7,?8,'GLD')`
  ).bind(sub, fecha, close, precioArs, fx || null, cant,
    String(b.entidad || "").slice(0, 40) || null, tipo).run();

  return { ok: true, id: res.meta.last_row_id, cant, close, pCedUsd, precioArs, ccl: fx };
}

// ---------------------------------------------------------------- precios
async function precioGld(env) {
  const cacheKey = new Request("https://cache.orito.internal/gld-simple");
  const cache = caches.default;
  const hit = await cache.match(cacheKey);
  if (hit) return hit;

  let historial = await desdeStooq();
  let fuente = "stooq";
  if (!historial) { historial = await desdeYahoo(); fuente = "yahoo"; }
  if (!historial || !historial.length) return json({ error: "no pude traer el precio" }, 502);

  let ccl = null;
  try {
    const r = await fetch("https://dolarapi.com/v1/dolares/contadoconliqui");
    if (r.ok) { const j = await r.json(); ccl = Number(j.venta || j.compra) || null; }
  } catch {}

  // precio real del cedear en BYMA (y de ahi el CCL implicito, el mas exacto)
  let cedear = null;
  try {
    const r = await fetch("https://data912.com/live/arg_cedears", { headers: { "User-Agent": "orito" } });
    if (r.ok) {
      const lista = await r.json();
      const g = Array.isArray(lista) ? lista.find((x) => (x.symbol || "").toUpperCase() === "GLD") : null;
      if (g && Number(g.c) > 0) {
        const close = historial[historial.length - 1].close;
        cedear = { precio: Number(g.c), pct: Number(g.pct_change) || null };
        cedear.cclImplicito = Math.round((cedear.precio / (close / RATIO)) * 100) / 100;
        if (cedear.cclImplicito > 0) ccl = cedear.cclImplicito;
      }
    }
  } catch {}

  const last = historial[historial.length - 1];
  const res = json({ precio: last.close, fecha: last.fecha, ccl, cedear, historial, fuente, ratio: RATIO });
  res.headers.set("Cache-Control", "public, max-age=900");
  await cache.put(cacheKey, res.clone());
  return res;
}

async function desdeStooq() {
  try {
    const f = (d) => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
    const r = await fetch(`https://stooq.com/q/d/l/?s=gld.us&i=d&d1=${f(new Date(Date.now() - 200 * 864e5))}&d2=${f(new Date())}`,
      { headers: { "User-Agent": "Mozilla/5.0 (orito)" } });
    if (!r.ok) return null;
    const csv = await r.text();
    if (!csv.startsWith("Date,")) return null;
    const out = [];
    for (const l of csv.trim().split("\n").slice(1)) {
      const c = l.split(",");
      if (c[0] && Number(c[4]) > 0) out.push({ fecha: c[0], close: Number(c[4]) });
    }
    return out.length ? out : null;
  } catch { return null; }
}

async function desdeYahoo() {
  try {
    const r = await fetch("https://query1.finance.yahoo.com/v8/finance/chart/GLD?range=6mo&interval=1d",
      { headers: { "User-Agent": "Mozilla/5.0 (orito)", Accept: "application/json" } });
    if (!r.ok) return null;
    const j = await r.json();
    const res = j && j.chart && j.chart.result && j.chart.result[0];
    if (!res) return null;
    const ts = res.timestamp || [];
    const cl = (res.indicators && res.indicators.quote && res.indicators.quote[0].close) || [];
    const out = [];
    for (let i = 0; i < ts.length; i++) {
      const c = Number(cl[i]);
      if (!(c > 0)) continue;
      out.push({ fecha: new Date(ts[i] * 1000).toISOString().slice(0, 10), close: Math.round(c * 100) / 100 });
    }
    return out.length ? out : null;
  } catch { return null; }
}

async function closeDe(env, fecha) {
  try {
    const r = await precioGld(env);
    if (!r.ok) return null;
    const j = await r.json();
    let v = null;
    for (const h of j.historial) { if (h.fecha <= fecha) v = h.close; else break; }
    return v != null ? v : (j.historial[0] ? j.historial[0].close : null);
  } catch { return null; }
}

async function cclDe(fecha) {
  for (let i = 0; i < 7; i++) {
    const d = new Date(fecha + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() - i);
    const y = d.getUTCFullYear(), m = String(d.getUTCMonth() + 1).padStart(2, "0"), dd = String(d.getUTCDate()).padStart(2, "0");
    try {
      const r = await fetch(`https://api.argentinadatos.com/v1/cotizaciones/dolares/contadoconliqui/${y}/${m}/${dd}`);
      if (r.ok) { const j = await r.json(); const v = Number(j.venta || j.compra); if (v > 0) return v; }
    } catch {}
  }
  try {
    const r = await fetch("https://dolarapi.com/v1/dolares/contadoconliqui");
    if (r.ok) { const j = await r.json(); return Number(j.venta || j.compra) || null; }
  } catch {}
  return null;
}

// ---------------------------------------------------------------- helpers
export const HELPERS = {
  // tenencia con costo promedio ponderado: la venta no cambia el ppc, realiza resultado
  async tenencia(env, sub) {
    const { results } = await env.DB.prepare(
      `SELECT precio_gld, precio_ars, cant, COALESCE(tipo,'compra') AS tipo FROM compras
       WHERE user_sub=?1 AND COALESCE(activo,'GLD')='GLD' ORDER BY fecha ASC, id ASC`
    ).bind(sub).all();

    let cant = 0, costoUsd = 0, costoArs = 0, realizado = 0;
    for (const o of results) {
      const p = o.precio_gld / RATIO;
      const pa = Number(o.precio_ars) || 0;
      if (o.tipo === "venta") {
        const ppc = cant > 0 ? costoUsd / cant : 0;
        const ppcA = cant > 0 ? costoArs / cant : 0;
        realizado += p * o.cant - ppc * o.cant;
        costoUsd -= ppc * o.cant;
        costoArs -= ppcA * o.cant;
        cant -= o.cant;
        if (cant < 1e-9) { cant = 0; costoUsd = 0; costoArs = 0; }
      } else {
        cant += o.cant; costoUsd += p * o.cant; costoArs += pa * o.cant;
      }
    }
    return { cant, costoUsd, costoArs, realizado, ppc: cant > 0 ? costoUsd / cant : NaN };
  },

  async estado(env, sub) {
    const t = await HELPERS.tenencia(env, sub);
    const r = await precioGld(env);
    if (!r.ok) return { error: "no pude traer el precio de GLD" };
    const px = await r.json();
    const valorUnit = px.precio / RATIO;
    const valor = t.cant * valorUnit;
    const pl = valor - t.costoUsd;
    const ppcGld = t.ppc * RATIO;
    const dif = ppcGld > 0 ? (px.precio - ppcGld) / ppcGld : NaN;
    return {
      ...t, px, valorUnit, valor, pl,
      plPct: t.costoUsd > 0 ? pl / t.costoUsd : NaN,
      ppcGld, dif,
      gatilloCompra: ppcGld * (1 - UMBRAL),
      gatilloVenta: ppcGld * (1 + UMBRAL),
      senal: !(t.cant > 0) ? "sin_posicion" : dif >= UMBRAL ? "vender" : dif <= -UMBRAL ? "comprar" : "esperar",
      valorArs: px.ccl ? valor * px.ccl : null,
    };
  },

  async resumen(env, sub) {
    const e = await HELPERS.estado(env, sub);
    if (e.error) return e.error;
    const usd = (n) => "US$ " + n.toFixed(2);
    const ars = (n) => "$ " + Math.round(n).toLocaleString("es-AR");
    if (!(e.cant > 0)) return "Todavia no tenes GLD cargado. Toca *Compre* y te lo anoto.";

    let out = `GLD ${usd(e.px.precio)} · ${e.px.fecha}\n\n`;
    out += `Tenes ${e.cant} cedears\n`;
    out += `Valor: ${usd(e.valor)}${e.valorArs ? " (" + ars(e.valorArs) + ")" : ""}\n`;
    out += `Invertido: ${usd(e.costoUsd)}\n`;
    out += `Resultado: ${e.pl >= 0 ? "+" : ""}${usd(e.pl)} (${e.pl >= 0 ? "+" : ""}${(e.plPct * 100).toFixed(2)}%)\n`;
    if (Math.abs(e.realizado) > 0.009) out += `Realizado: ${e.realizado >= 0 ? "+" : ""}${usd(e.realizado)}\n`;
    out += `\nTu precio promedio: ${usd(e.ppcGld)}\n`;
    if (e.senal === "vender") out += `\nVENDE HOY: esta ${(e.dif * 100).toFixed(1)}% arriba de tu promedio.`;
    else if (e.senal === "comprar") out += `\nCOMPRA HOY: cayo ${(Math.abs(e.dif) * 100).toFixed(1)}% debajo de tu promedio.`;
    else out += `\nEsperar. Vender en ${usd(e.gatilloVenta)} · comprar en ${usd(e.gatilloCompra)}.`;
    return out;
  },

  // calcula cuantos cedears salen con ese monto, antes de guardar
  async simular(env, sub, montoArs, cant) {
    const fecha = hoyIso();
    const close = await closeDe(env, fecha);
    const fx = await cclDe(fecha);
    if (!(close > 0) || !(fx > 0)) return { error: "no pude traer el precio o el dolar de hoy" };
    const pCedArs = (close / RATIO) * fx;
    const q = cant > 0 ? cant : Math.max(1, Math.round(montoArs / pCedArs));
    return { fecha, close, fx, pCedArs, cant: q, montoArs, real: montoArs / q };
  },

  guardar: (env, sub, datos) => guardarOperacion(env, sub, datos),

  async pendienteDe(env, sub) {
    const { results } = await env.DB.prepare("SELECT payload, creado FROM wa_pendientes WHERE user_sub=?1").bind(sub).all();
    if (!results.length) return null;
    if (Date.now() - Number(results[0].creado || 0) > 15 * 60 * 1000) {
      await HELPERS.limpiarPendiente(env, sub);
      return null;
    }
    return results[0];
  },
  async guardarPendiente(env, sub, payload) {
    await env.DB.prepare("DELETE FROM wa_pendientes WHERE user_sub=?1").bind(sub).run();
    await env.DB.prepare("INSERT INTO wa_pendientes (user_sub, payload, creado) VALUES (?1,?2,?3)")
      .bind(sub, payload, Date.now()).run();
  },
  async limpiarPendiente(env, sub) {
    await env.DB.prepare("DELETE FROM wa_pendientes WHERE user_sub=?1").bind(sub).run();
  },
};

// ---------------------------------------------------------------- aviso diario
async function avisoDiario(env) {
  const sub = env.WA_USER_SUB;
  const numero = String(env.WA_ALLOW || "").split(",")[0].trim();
  if (!sub || !numero) return;

  const e = await HELPERS.estado(env, sub);
  if (e.error || !(e.cant > 0) || e.senal === "esperar") return;

  const usd = (n) => "US$ " + n.toFixed(2);
  const hoy = hoyIso();

  // no repetir el mismo aviso mas de una vez por dia
  const marca = `aviso-${e.senal}-${hoy}`;
  const { results } = await env.DB.prepare(
    "SELECT payload FROM wa_pendientes WHERE user_sub=?1 AND payload=?2"
  ).bind(sub + "-aviso", marca).all();
  if (results.length) return;

  const texto = e.senal === "vender"
    ? `GLD toco tu regla del 20%.\n\n${usd(e.px.precio)} · ${(e.dif * 100).toFixed(1)}% arriba de tu promedio (${usd(e.ppcGld)}).\n` +
      `Vender todo hoy: ${usd(e.valor)} por ${e.cant} cedears (${e.pl >= 0 ? "+" : ""}${usd(e.pl)}).`
    : `GLD cayo ${(Math.abs(e.dif) * 100).toFixed(1)}% debajo de tu promedio.\n\n` +
      `${usd(e.px.precio)} contra ${usd(e.ppcGld)}. Toco tu regla de compra.`;

  await enviarWA(env, numero, texto);
  await env.DB.prepare(
    "INSERT OR REPLACE INTO wa_pendientes (user_sub, payload, creado) VALUES (?1,?2,?3)"
  ).bind(sub + "-aviso", marca, Date.now()).run();
}

// ---------------------------------------------------------------- utilidades
const hoyIso = () => new Date().toISOString().slice(0, 10);

async function session(request, env) {
  const raw = getCookie(request.headers.get("Cookie") || "", COOKIE);
  if (!raw) return null;
  const dot = raw.lastIndexOf(".");
  if (dot < 0) return null;
  const payload = raw.slice(0, dot), sig = raw.slice(dot + 1);
  if (sig !== (await hmac(env.SESSION_SECRET, payload))) return null;
  try {
    const d = JSON.parse(atob(payload.replace(/-/g, "+").replace(/_/g, "/")));
    return d.exp < Date.now() ? null : d;
  } catch { return null; }
}

function getCookie(header, name) {
  for (const p of header.split(";")) {
    const [k, ...v] = p.trim().split("=");
    if (k === name) return v.join("=");
  }
  return null;
}

async function hmac(secret, text) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(text));
  return b64url(String.fromCharCode(...new Uint8Array(sig)));
}

const b64url = (s) => btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status, headers: { "Content-Type": "application/json", ...extra },
  });
}
